-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: 127.0.0.1	Database: xintel
-- ------------------------------------------------------
-- Server version 	5.7.39
-- Date: Fri, 30 May 2025 04:16:35 +0000

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table activations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `code` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activations_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activations`
--

LOCK TABLES `activations` WRITE;
/*!40000 ALTER TABLE `activations` DISABLE KEYS */;
INSERT INTO `activations` VALUES (1,1,'DtoiWsBYwHgQQJFTjf81RzxkIoHK6Kxw',1,'2025-05-29 02:47:44','2025-05-29 02:47:44','2025-05-29 02:47:44');
/*!40000 ALTER TABLE `activations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `activations` with 1 row(s)
--

--
-- Table structure for table admin_notifications
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `permission` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_notifications`
--

LOCK TABLES `admin_notifications` WRITE;
/*!40000 ALTER TABLE `admin_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_notifications` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `admin_notifications` with 0 row(s)
--

--
-- Table structure for table audit_histories
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `module` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request` longtext COLLATE utf8mb4_unicode_ci,
  `action` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_user` bigint(20) unsigned NOT NULL,
  `reference_id` bigint(20) unsigned NOT NULL,
  `reference_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_histories_user_id_index` (`user_id`),
  KEY `audit_histories_module_index` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_histories`
--

LOCK TABLES `audit_histories` WRITE;
/*!40000 ALTER TABLE `audit_histories` DISABLE KEYS */;
INSERT INTO `audit_histories` VALUES (1,1,'language','{\"lang_id\":\"0\",\"lang_name\":\"English\",\"lang_locale\":\"en\",\"lang_code\":\"en_US\",\"lang_flag\":\"us\",\"lang_order\":\"0\",\"lang_is_rtl\":\"0\",\"lang_is_default\":1}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,1,'','info','2025-05-29 02:49:50','2025-05-29 02:49:50'),(2,1,'form','{\"name\":\"Main menu\",\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,1,'Main menu','info','2025-05-29 02:50:13','2025-05-29 02:50:13'),(3,1,'form','{\"data\":{\"menu_id\":\"1\",\"title\":\"Home\",\"url\":\"\\/\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"position\":\"2\"}}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,1,'Home','info','2025-05-29 02:50:19','2025-05-29 02:50:19'),(4,1,'form','{\"data\":{\"menu_id\":\"1\",\"title\":\"About\",\"url\":null,\"icon_font\":null,\"css_class\":null,\"position\":\"3\"}}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,2,'About','info','2025-05-29 02:50:23','2025-05-29 02:50:23'),(5,1,'form','{\"data\":{\"menu_id\":\"1\",\"title\":\"Roadmap\",\"url\":\"\\/roadmap\",\"icon_font\":null,\"css_class\":null,\"position\":\"4\"}}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,3,'Roadmap','info','2025-05-29 02:50:33','2025-05-29 02:50:33'),(6,1,'form','{\"data\":{\"menu_id\":\"1\",\"title\":\"Faq\",\"url\":\"\\/Faq\",\"icon_font\":null,\"css_class\":null,\"position\":\"5\"}}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,4,'Faq','info','2025-05-29 02:50:46','2025-05-29 02:50:46'),(7,1,'form','{\"data\":{\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"position\":\"6\"}}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,5,'Pages','info','2025-05-29 02:50:54','2025-05-29 02:50:54'),(8,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home\\\",\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":1,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"About\\\",\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":1,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":2,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Roadmap\\\",\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":2,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":3,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Faq\\\",\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":3,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":4,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Pages\\\",\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":4,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":5,\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,1,'Main menu','primary','2025-05-29 02:50:55','2025-05-29 02:50:55'),(9,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home\\\",\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":1,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"About\\\",\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":1,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":2,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Roadmap\\\",\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":2,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":3,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Faq\\\",\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":3,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":4,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Pages\\\",\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":4,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":5,\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,1,'Home','primary','2025-05-29 02:50:55','2025-05-29 02:50:55'),(10,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home\\\",\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":1,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"About\\\",\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":1,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":2,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Roadmap\\\",\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":2,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":3,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Faq\\\",\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":3,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":4,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Pages\\\",\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":4,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":5,\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,2,'About','primary','2025-05-29 02:50:55','2025-05-29 02:50:55'),(11,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home\\\",\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":1,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"About\\\",\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":1,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":2,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Roadmap\\\",\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":2,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":3,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Faq\\\",\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":3,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":4,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Pages\\\",\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":4,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":5,\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,3,'Roadmap','primary','2025-05-29 02:50:55','2025-05-29 02:50:55'),(12,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home\\\",\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":1,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"About\\\",\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":1,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":2,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Roadmap\\\",\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":2,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":3,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Faq\\\",\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":3,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":4,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Pages\\\",\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":4,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":5,\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,4,'Faq','primary','2025-05-29 02:50:56','2025-05-29 02:50:56'),(13,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home\\\",\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":1,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"About\\\",\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":1,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":2,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Roadmap\\\",\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":2,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":3,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Faq\\\",\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":3,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":4,\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Pages\\\",\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":4,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":5,\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,5,'Pages','primary','2025-05-29 02:50:56','2025-05-29 02:50:56'),(14,1,'menu_location','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,1,'ID: 1','info','2025-05-29 02:51:00','2025-05-29 02:51:00'),(15,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,1,'Main menu','primary','2025-05-29 02:51:00','2025-05-29 02:51:00'),(16,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,1,'Home','primary','2025-05-29 02:51:00','2025-05-29 02:51:00'),(17,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,2,'About','primary','2025-05-29 02:51:00','2025-05-29 02:51:00'),(18,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,3,'Roadmap','primary','2025-05-29 02:51:00','2025-05-29 02:51:00'),(19,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,4,'Faq','primary','2025-05-29 02:51:00','2025-05-29 02:51:00'),(20,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}}]\",\"menu_id\":\"1\",\"title\":\"Pages\",\"url\":\"\\/Pages\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,5,'Pages','primary','2025-05-29 02:51:00','2025-05-29 02:51:00'),(21,1,'form','{\"data\":{\"menu_id\":\"1\",\"title\":\"Home 1\",\"url\":\"\\/home-1\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"position\":\"7\"}}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,6,'Home 1','info','2025-05-29 09:30:40','2025-05-29 09:30:40'),(22,1,'form','{\"data\":{\"menu_id\":\"1\",\"title\":\"Home 2\",\"url\":\"\\/home-2\",\"icon_font\":null,\"css_class\":null,\"position\":\"8\"}}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,7,'Home 2','info','2025-05-29 09:30:49','2025-05-29 09:30:49'),(23,1,'form','{\"data\":{\"menu_id\":\"1\",\"title\":\"Blog\",\"url\":\"\\/blog\",\"icon_font\":null,\"css_class\":null,\"position\":\"9\"}}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,8,'Blog','info','2025-05-29 09:31:13','2025-05-29 09:31:13'),(24,1,'form','{\"data\":{\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"position\":\"10\"}}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,9,'Blog detail','info','2025-05-29 09:31:24','2025-05-29 09:31:24'),(25,1,'menu_location','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 1\\\",\\\"url\\\":\\\"\\/home-1\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":\\\"7\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":6}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 2\\\",\\\"url\\\":\\\"\\/home-2\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"8\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":7}}]},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog\\\",\\\"url\\\":\\\"\\/blog\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"9\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":8}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog detail\\\",\\\"url\\\":\\\"\\/blog-detail\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"10\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":9}}]}]\",\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','created','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,1,'ID: 1','info','2025-05-29 09:31:45','2025-05-29 09:31:45'),(26,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 1\\\",\\\"url\\\":\\\"\\/home-1\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":\\\"7\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":6}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 2\\\",\\\"url\\\":\\\"\\/home-2\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"8\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":7}}]},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog\\\",\\\"url\\\":\\\"\\/blog\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"9\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":8}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog detail\\\",\\\"url\\\":\\\"\\/blog-detail\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"10\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":9}}]}]\",\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,1,'Main menu','primary','2025-05-29 09:31:45','2025-05-29 09:31:45'),(27,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 1\\\",\\\"url\\\":\\\"\\/home-1\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":\\\"7\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":6}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 2\\\",\\\"url\\\":\\\"\\/home-2\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"8\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":7}}]},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog\\\",\\\"url\\\":\\\"\\/blog\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"9\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":8}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog detail\\\",\\\"url\\\":\\\"\\/blog-detail\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"10\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":9}}]}]\",\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,1,'Home','primary','2025-05-29 09:31:45','2025-05-29 09:31:45'),(28,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 1\\\",\\\"url\\\":\\\"\\/home-1\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":\\\"7\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":6}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 2\\\",\\\"url\\\":\\\"\\/home-2\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"8\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":7}}]},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog\\\",\\\"url\\\":\\\"\\/blog\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"9\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":8}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog detail\\\",\\\"url\\\":\\\"\\/blog-detail\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"10\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":9}}]}]\",\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,6,'Home 1','primary','2025-05-29 09:31:45','2025-05-29 09:31:45'),(29,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 1\\\",\\\"url\\\":\\\"\\/home-1\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":\\\"7\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":6}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 2\\\",\\\"url\\\":\\\"\\/home-2\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"8\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":7}}]},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog\\\",\\\"url\\\":\\\"\\/blog\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"9\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":8}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog detail\\\",\\\"url\\\":\\\"\\/blog-detail\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"10\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":9}}]}]\",\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,7,'Home 2','primary','2025-05-29 09:31:45','2025-05-29 09:31:45'),(30,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 1\\\",\\\"url\\\":\\\"\\/home-1\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":\\\"7\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":6}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 2\\\",\\\"url\\\":\\\"\\/home-2\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"8\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":7}}]},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog\\\",\\\"url\\\":\\\"\\/blog\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"9\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":8}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog detail\\\",\\\"url\\\":\\\"\\/blog-detail\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"10\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":9}}]}]\",\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,2,'About','primary','2025-05-29 09:31:45','2025-05-29 09:31:45'),(31,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 1\\\",\\\"url\\\":\\\"\\/home-1\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":\\\"7\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":6}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 2\\\",\\\"url\\\":\\\"\\/home-2\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"8\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":7}}]},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog\\\",\\\"url\\\":\\\"\\/blog\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"9\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":8}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog detail\\\",\\\"url\\\":\\\"\\/blog-detail\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"10\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":9}}]}]\",\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,3,'Roadmap','primary','2025-05-29 09:31:45','2025-05-29 09:31:45'),(32,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 1\\\",\\\"url\\\":\\\"\\/home-1\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":\\\"7\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":6}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 2\\\",\\\"url\\\":\\\"\\/home-2\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"8\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":7}}]},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog\\\",\\\"url\\\":\\\"\\/blog\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"9\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":8}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog detail\\\",\\\"url\\\":\\\"\\/blog-detail\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"10\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":9}}]}]\",\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,4,'Faq','primary','2025-05-29 09:31:45','2025-05-29 09:31:45'),(33,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 1\\\",\\\"url\\\":\\\"\\/home-1\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":\\\"7\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":6}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 2\\\",\\\"url\\\":\\\"\\/home-2\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"8\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":7}}]},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog\\\",\\\"url\\\":\\\"\\/blog\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"9\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":8}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog detail\\\",\\\"url\\\":\\\"\\/blog-detail\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"10\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":9}}]}]\",\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,5,'Pages','primary','2025-05-29 09:31:45','2025-05-29 09:31:45'),(34,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 1\\\",\\\"url\\\":\\\"\\/home-1\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":\\\"7\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":6}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 2\\\",\\\"url\\\":\\\"\\/home-2\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"8\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":7}}]},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog\\\",\\\"url\\\":\\\"\\/blog\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"9\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":8}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog detail\\\",\\\"url\\\":\\\"\\/blog-detail\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"10\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":9}}]}]\",\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,8,'Blog','primary','2025-05-29 09:31:45','2025-05-29 09:31:45'),(35,1,'form','{\"name\":\"Main menu\",\"deleted_nodes\":null,\"menu_nodes\":\"[{\\\"menuItem\\\":{\\\"id\\\":1,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":0,\\\"title\\\":\\\"Home\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 1\\\",\\\"url\\\":\\\"\\/home-1\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"position\\\":\\\"7\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":6}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Home 2\\\",\\\"url\\\":\\\"\\/home-2\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"8\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":7}}]},{\\\"menuItem\\\":{\\\"id\\\":2,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/about\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":1,\\\"title\\\":\\\"About\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":3,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/roadmap\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":2,\\\"title\\\":\\\"Roadmap\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":4,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Faq\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":3,\\\"title\\\":\\\"Faq\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]}},{\\\"menuItem\\\":{\\\"id\\\":5,\\\"menu_id\\\":1,\\\"parent_id\\\":0,\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"url\\\":\\\"\\/Pages\\\",\\\"icon_font\\\":\\\"\\\",\\\"position\\\":4,\\\"title\\\":\\\"Pages\\\",\\\"css_class\\\":\\\"\\\",\\\"target\\\":\\\"_self\\\",\\\"has_child\\\":0,\\\"reference\\\":null,\\\"metadata\\\":[],\\\"children\\\":[]},\\\"children\\\":[{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog\\\",\\\"url\\\":\\\"\\/blog\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"9\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":8}},{\\\"menuItem\\\":{\\\"menu_id\\\":\\\"1\\\",\\\"title\\\":\\\"Blog detail\\\",\\\"url\\\":\\\"\\/blog-detail\\\",\\\"icon_font\\\":\\\"\\\",\\\"css_class\\\":\\\"\\\",\\\"position\\\":\\\"10\\\",\\\"reference_id\\\":0,\\\"reference_type\\\":null,\\\"id\\\":9}}]}]\",\"menu_id\":\"1\",\"title\":\"Blog detail\",\"url\":\"\\/blog-detail\",\"icon_font\":null,\"css_class\":null,\"target\":\"_self\",\"locations\":[\"main-menu\"],\"submitter\":\"apply\",\"language\":\"en_US\",\"status\":\"published\"}','updated','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',1,9,'Blog detail','primary','2025-05-29 09:31:45','2025-05-29 09:31:45'),(36,1,'to the system',NULL,'logged in','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','::1',0,1,'Admin Admin','info','2025-05-29 21:06:21','2025-05-29 21:06:21');
/*!40000 ALTER TABLE `audit_histories` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `audit_histories` with 36 row(s)
--

--
-- Table structure for table blocks
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blocks_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocks`
--

LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `blocks` with 0 row(s)
--

--
-- Table structure for table blocks_translations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocks_translations` (
  `lang_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blocks_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`lang_code`,`blocks_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocks_translations`
--

LOCK TABLES `blocks_translations` WRITE;
/*!40000 ALTER TABLE `blocks_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocks_translations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `blocks_translations` with 0 row(s)
--

--
-- Table structure for table categories
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `author_id` bigint(20) unsigned DEFAULT NULL,
  `author_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Botble\\ACL\\Models\\User',
  `icon` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` tinyint(4) NOT NULL DEFAULT '0',
  `is_featured` tinyint(4) NOT NULL DEFAULT '0',
  `is_default` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_parent_id_index` (`parent_id`),
  KEY `categories_status_index` (`status`),
  KEY `categories_created_at_index` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `categories` with 0 row(s)
--

--
-- Table structure for table categories_translations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories_translations` (
  `lang_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categories_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`lang_code`,`categories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories_translations`
--

LOCK TABLES `categories_translations` WRITE;
/*!40000 ALTER TABLE `categories_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories_translations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `categories_translations` with 0 row(s)
--

--
-- Table structure for table contact_replies
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_replies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_replies`
--

LOCK TABLES `contact_replies` WRITE;
/*!40000 ALTER TABLE `contact_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_replies` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `contact_replies` with 0 row(s)
--

--
-- Table structure for table contacts
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unread',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `contacts` with 0 row(s)
--

--
-- Table structure for table custom_fields
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `use_for` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `use_for_id` bigint(20) unsigned NOT NULL,
  `field_item_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `custom_fields_field_item_id_index` (`field_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `custom_fields` with 0 row(s)
--

--
-- Table structure for table custom_fields_translations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields_translations` (
  `lang_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_fields_id` bigint(20) unsigned NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`lang_code`,`custom_fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields_translations`
--

LOCK TABLES `custom_fields_translations` WRITE;
/*!40000 ALTER TABLE `custom_fields_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields_translations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `custom_fields_translations` with 0 row(s)
--

--
-- Table structure for table dashboard_widget_settings
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_widget_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `settings` text COLLATE utf8mb4_unicode_ci,
  `user_id` bigint(20) unsigned NOT NULL,
  `widget_id` bigint(20) unsigned NOT NULL,
  `order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboard_widget_settings_user_id_index` (`user_id`),
  KEY `dashboard_widget_settings_widget_id_index` (`widget_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_widget_settings`
--

LOCK TABLES `dashboard_widget_settings` WRITE;
/*!40000 ALTER TABLE `dashboard_widget_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_widget_settings` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `dashboard_widget_settings` with 0 row(s)
--

--
-- Table structure for table dashboard_widgets
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_widgets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_widgets`
--

LOCK TABLES `dashboard_widgets` WRITE;
/*!40000 ALTER TABLE `dashboard_widgets` DISABLE KEYS */;
INSERT INTO `dashboard_widgets` VALUES (1,'widget_total_themes','2025-05-29 02:48:12','2025-05-29 02:48:12'),(2,'widget_total_users','2025-05-29 02:48:12','2025-05-29 02:48:12'),(3,'widget_total_plugins','2025-05-29 02:48:12','2025-05-29 02:48:12'),(4,'widget_total_pages','2025-05-29 02:48:12','2025-05-29 02:48:12');
/*!40000 ALTER TABLE `dashboard_widgets` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `dashboard_widgets` with 4 row(s)
--

--
-- Table structure for table failed_jobs
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `failed_jobs` with 0 row(s)
--

--
-- Table structure for table field_groups
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rules` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '0',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `field_groups_created_by_index` (`created_by`),
  KEY `field_groups_updated_by_index` (`updated_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_groups`
--

LOCK TABLES `field_groups` WRITE;
/*!40000 ALTER TABLE `field_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `field_groups` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `field_groups` with 0 row(s)
--

--
-- Table structure for table field_items
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `field_group_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `order` int(11) DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instructions` text COLLATE utf8mb4_unicode_ci,
  `options` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `field_items_field_group_id_index` (`field_group_id`),
  KEY `field_items_parent_id_index` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_items`
--

LOCK TABLES `field_items` WRITE;
/*!40000 ALTER TABLE `field_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `field_items` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `field_items` with 0 row(s)
--

--
-- Table structure for table galleries
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_featured` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `galleries_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries`
--

LOCK TABLES `galleries` WRITE;
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `galleries` with 0 row(s)
--

--
-- Table structure for table galleries_translations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries_translations` (
  `lang_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `galleries_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`lang_code`,`galleries_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries_translations`
--

LOCK TABLES `galleries_translations` WRITE;
/*!40000 ALTER TABLE `galleries_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `galleries_translations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `galleries_translations` with 0 row(s)
--

--
-- Table structure for table gallery_meta
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gallery_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `images` text COLLATE utf8mb4_unicode_ci,
  `reference_id` bigint(20) unsigned NOT NULL,
  `reference_type` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gallery_meta_reference_id_index` (`reference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery_meta`
--

LOCK TABLES `gallery_meta` WRITE;
/*!40000 ALTER TABLE `gallery_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `gallery_meta` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `gallery_meta` with 0 row(s)
--

--
-- Table structure for table gallery_meta_translations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gallery_meta_translations` (
  `lang_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gallery_meta_id` bigint(20) unsigned NOT NULL,
  `images` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`lang_code`,`gallery_meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery_meta_translations`
--

LOCK TABLES `gallery_meta_translations` WRITE;
/*!40000 ALTER TABLE `gallery_meta_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `gallery_meta_translations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `gallery_meta_translations` with 0 row(s)
--

--
-- Table structure for table jobs
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `jobs` with 0 row(s)
--

--
-- Table structure for table language_meta
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language_meta` (
  `lang_meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lang_meta_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lang_meta_origin` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_id` bigint(20) unsigned NOT NULL,
  `reference_type` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`lang_meta_id`),
  KEY `language_meta_reference_id_index` (`reference_id`),
  KEY `meta_code_index` (`lang_meta_code`),
  KEY `meta_origin_index` (`lang_meta_origin`),
  KEY `meta_reference_type_index` (`reference_type`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language_meta`
--

LOCK TABLES `language_meta` WRITE;
/*!40000 ALTER TABLE `language_meta` DISABLE KEYS */;
INSERT INTO `language_meta` VALUES (1,'en_US','5292b28c70273019a3d4a735b097d30b',1,'Botble\\Menu\\Models\\Menu'),(2,'en_US','c325f6991d75b1074d52beea18dee10c',1,'Botble\\Menu\\Models\\MenuNode'),(3,'en_US','fb1ff6ca0bcd61aa396a83c68453e198',2,'Botble\\Menu\\Models\\MenuNode'),(4,'en_US','4b94402e2a08ccb375a3a3244def748d',3,'Botble\\Menu\\Models\\MenuNode'),(5,'en_US','a4b019d1f1968e18a885643ae65fcc42',4,'Botble\\Menu\\Models\\MenuNode'),(6,'en_US','50c7a06ae29678a137f7b661c555d233',5,'Botble\\Menu\\Models\\MenuNode'),(7,'en_US','348a095b46b43f66134f1b129c543ed8',6,'Botble\\Menu\\Models\\MenuNode'),(8,'en_US','0deb767c24b0e354b5ab9adf1f3e9ed3',7,'Botble\\Menu\\Models\\MenuNode'),(9,'en_US','a33603ffc06c8e150126e78699b5d7ec',8,'Botble\\Menu\\Models\\MenuNode'),(10,'en_US','f9bc95fec015c8ba443676acadc72e5d',9,'Botble\\Menu\\Models\\MenuNode');
/*!40000 ALTER TABLE `language_meta` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `language_meta` with 10 row(s)
--

--
-- Table structure for table languages
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `lang_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lang_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_locale` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_flag` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lang_is_default` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `lang_order` int(11) NOT NULL DEFAULT '0',
  `lang_is_rtl` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  KEY `lang_locale_index` (`lang_locale`),
  KEY `lang_code_index` (`lang_code`),
  KEY `lang_is_default_index` (`lang_is_default`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'English','en','en_US','us',1,0,0);
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `languages` with 1 row(s)
--

--
-- Table structure for table media_files
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mime_type` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int(11) NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_files_user_id_index` (`user_id`),
  KEY `media_files_index` (`folder_id`,`user_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_files`
--

LOCK TABLES `media_files` WRITE;
/*!40000 ALTER TABLE `media_files` DISABLE KEYS */;
INSERT INTO `media_files` VALUES (2,1,'fb','fb',0,'image/png',700,'fb.png','[]','2025-05-29 12:07:47','2025-05-29 12:07:47',NULL),(3,1,'Hero-asset','Hero-asset',0,'image/png',318923,'hero-asset.png','[]','2025-05-29 12:07:48','2025-05-29 12:07:48',NULL),(4,1,'mail','mail',0,'image/png',1058,'mail.png','[]','2025-05-29 12:07:48','2025-05-29 12:07:48',NULL),(5,1,'tiktok','tiktok',0,'image/png',1075,'tiktok.png','[]','2025-05-29 12:07:49','2025-05-29 12:07:49',NULL),(7,1,'Logo','Logo',0,'image/png',26123,'logo.png','[]','2025-05-29 21:08:46','2025-05-29 21:08:46',NULL);
/*!40000 ALTER TABLE `media_files` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `media_files` with 5 row(s)
--

--
-- Table structure for table media_folders
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_folders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_folders_user_id_index` (`user_id`),
  KEY `media_folders_index` (`parent_id`,`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_folders`
--

LOCK TABLES `media_folders` WRITE;
/*!40000 ALTER TABLE `media_folders` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_folders` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `media_folders` with 0 row(s)
--

--
-- Table structure for table media_settings
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `media_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_settings`
--

LOCK TABLES `media_settings` WRITE;
/*!40000 ALTER TABLE `media_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_settings` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `media_settings` with 0 row(s)
--

--
-- Table structure for table member_activity_logs
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_activity_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `reference_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `member_activity_logs_member_id_index` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_activity_logs`
--

LOCK TABLES `member_activity_logs` WRITE;
/*!40000 ALTER TABLE `member_activity_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `member_activity_logs` with 0 row(s)
--

--
-- Table structure for table member_password_resets
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `member_password_resets_email_index` (`email`),
  KEY `member_password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_password_resets`
--

LOCK TABLES `member_password_resets` WRITE;
/*!40000 ALTER TABLE `member_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `member_password_resets` with 0 row(s)
--

--
-- Table structure for table members
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `gender` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar_id` bigint(20) unsigned DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phone` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `email_verify_token` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  PRIMARY KEY (`id`),
  UNIQUE KEY `members_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `members` with 0 row(s)
--

--
-- Table structure for table menu_locations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_locations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` bigint(20) unsigned NOT NULL,
  `location` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_locations_menu_id_created_at_index` (`menu_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_locations`
--

LOCK TABLES `menu_locations` WRITE;
/*!40000 ALTER TABLE `menu_locations` DISABLE KEYS */;
INSERT INTO `menu_locations` VALUES (1,1,'main-menu','2025-05-29 02:51:00','2025-05-29 02:51:00');
/*!40000 ALTER TABLE `menu_locations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `menu_locations` with 1 row(s)
--

--
-- Table structure for table menu_nodes
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_nodes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `reference_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_font` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `css_class` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `has_child` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_nodes_menu_id_index` (`menu_id`),
  KEY `menu_nodes_parent_id_index` (`parent_id`),
  KEY `reference_id` (`reference_id`),
  KEY `reference_type` (`reference_type`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_nodes`
--

LOCK TABLES `menu_nodes` WRITE;
/*!40000 ALTER TABLE `menu_nodes` DISABLE KEYS */;
INSERT INTO `menu_nodes` VALUES (1,1,0,0,NULL,'/','',0,'Home','','_self',1,'2025-05-29 02:50:19','2025-05-29 09:31:45'),(2,1,0,0,NULL,'/about','',1,'About','','_self',0,'2025-05-29 02:50:23','2025-05-29 09:31:45'),(3,1,0,0,NULL,'/roadmap','',2,'Roadmap','','_self',0,'2025-05-29 02:50:33','2025-05-29 09:31:45'),(4,1,0,0,NULL,'/Faq','',3,'Faq','','_self',0,'2025-05-29 02:50:46','2025-05-29 09:31:45'),(5,1,0,0,NULL,'/Pages','',4,'Pages','','_self',1,'2025-05-29 02:50:54','2025-05-29 09:31:45'),(6,1,1,0,NULL,'/home-1','',0,'Home 1','','_self',0,'2025-05-29 09:30:40','2025-05-29 09:31:45'),(7,1,1,0,NULL,'/home-2','',1,'Home 2','','_self',0,'2025-05-29 09:30:49','2025-05-29 09:31:45'),(8,1,5,0,NULL,'/blog','',0,'Blog','','_self',0,'2025-05-29 09:31:13','2025-05-29 09:31:45'),(9,1,5,0,NULL,'/blog-detail','',1,'Blog detail','','_self',0,'2025-05-29 09:31:24','2025-05-29 09:31:45');
/*!40000 ALTER TABLE `menu_nodes` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `menu_nodes` with 9 row(s)
--

--
-- Table structure for table menus
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menus_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'Main menu','main-menu','published','2025-05-29 02:50:13','2025-05-29 09:31:45');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `menus` with 1 row(s)
--

--
-- Table structure for table meta_boxes
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta_boxes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value` text COLLATE utf8mb4_unicode_ci,
  `reference_id` bigint(20) unsigned NOT NULL,
  `reference_type` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meta_boxes_reference_id_index` (`reference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_boxes`
--

LOCK TABLES `meta_boxes` WRITE;
/*!40000 ALTER TABLE `meta_boxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `meta_boxes` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `meta_boxes` with 0 row(s)
--

--
-- Table structure for table migrations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2013_04_09_032329_create_base_tables',1),(2,'2013_04_09_062329_create_revisions_table',1),(3,'2014_10_12_000000_create_users_table',1),(4,'2014_10_12_100000_create_password_reset_tokens_table',1),(5,'2016_06_10_230148_create_acl_tables',1),(6,'2016_06_14_230857_create_menus_table',1),(7,'2016_06_28_221418_create_pages_table',1),(8,'2016_10_05_074239_create_setting_table',1),(9,'2016_11_28_032840_create_dashboard_widget_tables',1),(10,'2016_12_16_084601_create_widgets_table',1),(11,'2017_05_09_070343_create_media_tables',1),(12,'2017_11_03_070450_create_slug_table',1),(13,'2019_01_05_053554_create_jobs_table',1),(14,'2019_08_19_000000_create_failed_jobs_table',1),(15,'2019_12_14_000001_create_personal_access_tokens_table',1),(16,'2022_04_20_100851_add_index_to_media_table',1),(17,'2022_04_20_101046_add_index_to_menu_table',1),(18,'2022_07_10_034813_move_lang_folder_to_root',1),(19,'2022_08_04_051940_add_missing_column_expires_at',1),(20,'2022_09_01_000001_create_admin_notifications_tables',1),(21,'2022_10_14_024629_drop_column_is_featured',1),(22,'2022_11_18_063357_add_missing_timestamp_in_table_settings',1),(23,'2022_12_02_093615_update_slug_index_columns',1),(24,'2023_01_30_024431_add_alt_to_media_table',1),(25,'2023_02_16_042611_drop_table_password_resets',1),(26,'2023_04_23_005903_add_column_permissions_to_admin_notifications',1),(27,'2023_05_10_075124_drop_column_id_in_role_users_table',1),(28,'2023_08_21_090810_make_page_content_nullable',1),(29,'2023_09_14_021936_update_index_for_slugs_table',1),(30,'2023_12_06_100448_change_random_hash_for_media',1),(31,'2023_12_07_095130_add_color_column_to_media_folders_table',1),(32,'2023_12_17_162208_make_sure_column_color_in_media_folders_nullable',1),(33,'2015_06_29_025744_create_audit_history',2),(34,'2023_11_14_033417_change_request_column_in_table_audit_histories',2),(35,'2017_02_13_034601_create_blocks_table',3),(36,'2021_12_03_081327_create_blocks_translations',3),(37,'2016_06_17_091537_create_contacts_table',4),(38,'2023_11_10_080225_migrate_contact_blacklist_email_domains_to_core',4),(39,'2015_06_18_033822_create_blog_table',5),(40,'2021_02_16_092633_remove_default_value_for_author_type',5),(41,'2021_12_03_030600_create_blog_translations',5),(42,'2022_04_19_113923_add_index_to_table_posts',5),(43,'2023_08_29_074620_make_column_author_id_nullable',5),(44,'2017_03_27_150646_re_create_custom_field_tables',6),(45,'2022_04_30_030807_table_custom_fields_translation_table',6),(46,'2016_10_13_150201_create_galleries_table',7),(47,'2021_12_03_082953_create_gallery_translations',7),(48,'2022_04_30_034048_create_gallery_meta_translations_table',7),(49,'2023_08_29_075308_make_column_user_id_nullable',7),(50,'2016_10_03_032336_create_languages_table',8),(51,'2023_09_14_022423_add_index_for_language_table',8),(52,'2016_10_07_193005_create_translations_table',9),(53,'2023_12_12_105220_drop_translations_table',9),(54,'2021_10_25_021023_fix-priority-load-for-language-advanced',10),(55,'2021_12_03_075608_create_page_translations',10),(56,'2023_07_06_011444_create_slug_translations_table',10),(57,'2017_10_04_140938_create_member_table',11),(58,'2023_10_16_075332_add_status_column',11),(59,'2016_05_28_112028_create_system_request_logs_table',12);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `migrations` with 59 row(s)
--

--
-- Table structure for table pages
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pages_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `pages` with 0 row(s)
--

--
-- Table structure for table pages_translations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_translations` (
  `lang_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pages_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`lang_code`,`pages_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_translations`
--

LOCK TABLES `pages_translations` WRITE;
/*!40000 ALTER TABLE `pages_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages_translations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `pages_translations` with 0 row(s)
--

--
-- Table structure for table password_reset_tokens
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `password_reset_tokens` with 0 row(s)
--

--
-- Table structure for table personal_access_tokens
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `personal_access_tokens` with 0 row(s)
--

--
-- Table structure for table post_categories
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_categories` (
  `category_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  KEY `post_categories_category_id_index` (`category_id`),
  KEY `post_categories_post_id_index` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_categories`
--

LOCK TABLES `post_categories` WRITE;
/*!40000 ALTER TABLE `post_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_categories` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `post_categories` with 0 row(s)
--

--
-- Table structure for table post_tags
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_tags` (
  `tag_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  KEY `post_tags_tag_id_index` (`tag_id`),
  KEY `post_tags_post_id_index` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_tags`
--

LOCK TABLES `post_tags` WRITE;
/*!40000 ALTER TABLE `post_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_tags` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `post_tags` with 0 row(s)
--

--
-- Table structure for table posts
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `author_id` bigint(20) unsigned DEFAULT NULL,
  `author_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Botble\\ACL\\Models\\User',
  `is_featured` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `format_type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_status_index` (`status`),
  KEY `posts_author_id_index` (`author_id`),
  KEY `posts_author_type_index` (`author_type`),
  KEY `posts_created_at_index` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `posts` with 0 row(s)
--

--
-- Table structure for table posts_translations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_translations` (
  `lang_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `posts_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`lang_code`,`posts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_translations`
--

LOCK TABLES `posts_translations` WRITE;
/*!40000 ALTER TABLE `posts_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_translations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `posts_translations` with 0 row(s)
--

--
-- Table structure for table request_logs
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `request_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status_code` int(11) DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referrer` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request_logs`
--

LOCK TABLES `request_logs` WRITE;
/*!40000 ALTER TABLE `request_logs` DISABLE KEYS */;
INSERT INTO `request_logs` VALUES (1,404,'https://xintel.td/assets/img/logo.svg',21,NULL,NULL,'2025-05-29 05:57:25','2025-05-29 08:47:43'),(2,404,'https://xintel.td/assets/img/footer_logo.svg',6,NULL,NULL,'2025-05-29 05:57:25','2025-05-29 06:19:25'),(3,404,'https://xintel.td/assets/img/cta_img_1.png',6,NULL,NULL,'2025-05-29 05:57:25','2025-05-29 06:19:25'),(4,404,'https://xintel.td/themes/xintel/css/bootstrap.min.css',1,NULL,NULL,'2025-05-29 06:19:07','2025-05-29 06:19:07'),(5,404,'https://xintel.td/themes/xintel/css/slick.min.css',1,NULL,NULL,'2025-05-29 06:19:07','2025-05-29 06:19:07'),(6,404,'https://xintel.td/themes/xintel/css/fontawesome.min.css',1,NULL,NULL,'2025-05-29 06:19:07','2025-05-29 06:19:07'),(7,404,'https://xintel.td/themes/xintel/css/odometer.css',1,NULL,NULL,'2025-05-29 06:19:07','2025-05-29 06:19:07'),(8,404,'https://xintel.td/themes/xintel/fonts/conthrax/conthrax-sb.ttf',4,NULL,NULL,'2025-05-29 06:19:25','2025-05-29 06:32:59'),(9,404,'https://xintel.td/themes/xintel/fonts/urbanist/static/Urbanist-Bold.ttf',4,NULL,NULL,'2025-05-29 06:19:26','2025-05-29 06:32:59'),(10,404,'https://xintel.td/themes/xintel/fonts/urbanist/static/Urbanist-Medium.ttf',4,NULL,NULL,'2025-05-29 06:19:26','2025-05-29 06:32:59'),(11,404,'https://xintel.td/themes//images/cta_img_1.png',10,NULL,NULL,'2025-05-29 06:25:43','2025-05-29 06:50:54'),(12,404,'https://xintel.td/themes//images/footer_logo.svg',10,NULL,NULL,'2025-05-29 06:25:43','2025-05-29 06:50:54'),(13,404,'https://xintel.td/themes/xintel/css/responsive.css',1,NULL,NULL,'2025-05-29 06:28:02','2025-05-29 06:28:02'),(14,404,'https://xintel.td/themes/xintel/js/jquery-3.6.0.min.js',1,NULL,NULL,'2025-05-29 06:32:58','2025-05-29 06:32:58'),(15,404,'https://xintel.td/themes/xintel/js/jquery.slick.min.js',1,NULL,NULL,'2025-05-29 06:32:58','2025-05-29 06:32:58'),(16,404,'https://xintel.td/themes/xintel/js/wow.min.js',1,NULL,NULL,'2025-05-29 06:32:58','2025-05-29 06:32:58'),(17,404,'https://xintel.td/themes/xintel/js/main.js',1,NULL,NULL,'2025-05-29 06:32:59','2025-05-29 06:32:59'),(18,404,'https://xintel.td/assets/img/footer_bg.png',1,NULL,NULL,'2025-05-29 06:35:17','2025-05-29 06:35:17'),(19,404,'https://xintel.td/themes//images/footer_bg.png',9,NULL,NULL,'2025-05-29 06:49:31','2025-05-29 06:50:54'),(20,404,'https://xintel.td/themes/xintel/images/footer_bg.png',9,NULL,NULL,'2025-05-29 06:50:01','2025-05-29 06:50:53'),(21,404,'https://xintel.td/themes/xintel/images/assets/img/logo.svg',6,NULL,NULL,'2025-05-29 06:50:02','2025-05-29 06:50:54'),(22,404,'https://xintel.td/themes//logo.svg',2,NULL,NULL,'2025-05-29 08:49:27','2025-05-29 08:51:29'),(23,404,'https://xintel.td/apple-touch-icon-precomposed.png',5,NULL,NULL,'2025-05-29 11:47:11','2025-05-29 20:01:57'),(24,404,'https://xintel.td/apple-touch-icon.png',5,NULL,NULL,'2025-05-29 11:47:11','2025-05-29 20:01:57'),(25,404,'https://xintel.td/assets/img/icons/tick.svg',6,NULL,NULL,'2025-05-29 21:04:26','2025-05-29 21:09:08'),(26,404,'https://xintel.td/assets/img/history_left_1.png',6,NULL,NULL,'2025-05-29 21:04:26','2025-05-29 21:09:08'),(27,404,'https://xintel.td/storage/logo-1-150x150.png',1,NULL,NULL,'2025-05-29 21:08:57','2025-05-29 21:08:57');
/*!40000 ALTER TABLE `request_logs` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `request_logs` with 27 row(s)
--

--
-- Table structure for table revisions
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `revisionable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revisionable_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `key` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci,
  `new_value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `revisions` with 0 row(s)
--

--
-- Table structure for table role_users
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_users` (
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_users_user_id_index` (`user_id`),
  KEY `role_users_role_id_index` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_users`
--

LOCK TABLES `role_users` WRITE;
/*!40000 ALTER TABLE `role_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_users` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `role_users` with 0 row(s)
--

--
-- Table structure for table roles
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `created_by` bigint(20) unsigned NOT NULL,
  `updated_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_slug_unique` (`slug`),
  KEY `roles_created_by_index` (`created_by`),
  KEY `roles_updated_by_index` (`updated_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `roles` with 0 row(s)
--

--
-- Table structure for table settings
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'media_random_hash','cf7a3bc31726206b037b25f371196ac8',NULL,'2025-05-29 21:09:05'),(2,'activated_plugins','[\"language\",\"language-advanced\",\"analytics\",\"audit-log\",\"backup\",\"block\",\"cookie-consent\",\"contact\",\"captcha\",\"blog\",\"gallery\",\"translation\",\"member\",\"request-log\",\"custom-field\",\"social-login\"]',NULL,'2025-05-29 21:09:05'),(3,'theme','xintel',NULL,'2025-05-29 21:09:05'),(4,'theme-xintel-copyright','© 2024, XIN. All rights reserved. XINTEL CORPORATION LIMITED',NULL,'2025-05-29 21:09:05'),(5,'theme-xintel-primary_font','Manrope',NULL,'2025-05-29 21:09:05'),(6,'theme-xintel-site_title','',NULL,'2025-05-29 21:09:05'),(7,'theme-xintel-show_site_name','0',NULL,'2025-05-29 21:09:05'),(8,'theme-xintel-seo_title','',NULL,'2025-05-29 21:09:05'),(9,'theme-xintel-seo_description','',NULL,'2025-05-29 21:09:05'),(10,'theme-xintel-seo_og_image','',NULL,'2025-05-29 21:09:05'),(11,'theme-xintel-theme_breadcrumb_enabled','1',NULL,'2025-05-29 21:09:05'),(12,'theme-xintel-banner_heading','What the XIN App Brings to You',NULL,'2025-05-29 21:09:05'),(13,'theme-xintel-banner_text','XIN is not just a simple travel platform; it is a space for users to express their passion for sharing stories of exploration and self-expression. Sharing photos, videos, and travel experiences has become an essential part of online life, and many social platforms are leveraging this trend to offer travel related services and experiences.',NULL,'2025-05-29 21:09:05'),(14,'theme-xintel-banner_text_two','XIN offers a powerful feature that enhances your overall travel experience and gives you a great opportunity to earn exciting rewards every second as you explore the world.',NULL,'2025-05-29 21:09:05'),(15,'theme-xintel-banner_image','',NULL,'2025-05-29 21:09:05'),(16,'theme-xintel-gallery_heading','WHAT IS XIN?',NULL,'2025-05-29 21:09:05'),(17,'theme-xintel-gallery_sub_heading','XIN is more than just a travel platform – it’s a space to share emotions, images, videos, and vibrant exploration experiences. Here, you don’t just inspire the community – you earn rewards every second as you connect and interact with the world.',NULL,'2025-05-29 21:09:05'),(18,'theme-xintel-gallery_1_image','',NULL,'2025-05-29 21:09:05'),(19,'theme-xintel-gallery_1_title','Transaction Fees',NULL,'2025-05-29 21:09:05'),(20,'theme-xintel-gallery_1_content','From the exchange of services, products, and financial interactions between users, merchants, and businesses within the ecosystem.',NULL,'2025-05-29 21:09:05'),(21,'theme-xintel-gallery_2_image','',NULL,'2025-05-29 21:09:05'),(22,'theme-xintel-gallery_2_title','In app Purchases',NULL,'2025-05-29 21:09:05'),(23,'theme-xintel-gallery_2_content','Users pay to access premium utilities such as games, featured content display, shopping, and digital events.',NULL,'2025-05-29 21:09:05'),(24,'theme-xintel-gallery_3_image','',NULL,'2025-05-29 21:09:05'),(25,'theme-xintel-gallery_3_title','Subscription &amp; Membership',NULL,'2025-05-29 21:09:05'),(26,'theme-xintel-gallery_3_content','Enhanced membership packages offer extended access, travel and financial benefits, and exclusive community privileges.',NULL,'2025-05-29 21:09:05'),(27,'theme-xintel-gallery_4_image','',NULL,'2025-05-29 21:09:05'),(28,'theme-xintel-gallery_4_title','Commercial Partnerships &amp; OTT Marketplace',NULL,'2025-05-29 21:09:05'),(29,'theme-xintel-gallery_4_content','Businesses pay to set up storefronts, promote offerings, or integrate XIN payment within their platforms.',NULL,'2025-05-29 21:09:05'),(30,'theme-xintel-gallery_5_image','',NULL,'2025-05-29 21:09:05'),(31,'theme-xintel-gallery_5_title','Payments via XIN Token',NULL,'2025-05-29 21:09:05'),(32,'theme-xintel-gallery_5_content','Used for all services — tours, game items, OTT, and storefronts — seamlessly and securely.',NULL,'2025-05-29 21:09:05'),(33,'theme-xintel-gallery_6_image','',NULL,'2025-05-29 21:09:05'),(34,'theme-xintel-gallery_6_title','Staking XIN Token',NULL,'2025-05-29 21:09:05'),(35,'theme-xintel-gallery_6_content','Earn periodic rewards, unlock premium content, and participate in community governance.',NULL,'2025-05-29 21:09:05'),(36,'theme-xintel-growth_background_image','',NULL,'2025-05-29 21:09:05'),(37,'theme-xintel-growth_title','Growth Mechanism',NULL,'2025-05-29 21:09:05'),(38,'theme-xintel-growth_description','XIN is a platform that combines three core pillars: Travel &amp; Earn, Social FI, and a Payment Gateway — making travel easier, fostering community connections, and enabling secure blockchain-based payments.',NULL,'2025-05-29 21:09:05'),(39,'theme-xintel-growth_mission_title','Mission',NULL,'2025-05-29 21:09:05'),(40,'theme-xintel-growth_mission_description','To help users earn while traveling, connect global communities, and simplify international payments on a secure platform.',NULL,'2025-05-29 21:09:05'),(41,'theme-xintel-growth_mission_image','',NULL,'2025-05-29 21:09:05'),(42,'theme-xintel-growth_goal_title','Goal',NULL,'2025-05-29 21:09:05'),(43,'theme-xintel-growth_goal_description','By 2028, XIN aims to connect millions of travelers, promote cultural exchange, and become a globally influential travel platform.',NULL,'2025-05-29 21:09:05'),(44,'theme-xintel-growth_goal_image','',NULL,'2025-05-29 21:09:05'),(45,'theme-xintel-growth_vision_title','Vision',NULL,'2025-05-29 21:09:05'),(46,'theme-xintel-growth_vision_description','To become the leading platform where travel is not just an experience, but a chance to create value — with flexible services tailored to every user’s needs.',NULL,'2025-05-29 21:09:05'),(47,'theme-xintel-growth_vision_image','',NULL,'2025-05-29 21:09:05'),(48,'theme-xintel-ecosystem_section_heading','XIN Ecosystem',NULL,'2025-05-29 21:09:05'),(49,'theme-xintel-ecosystem_section_description','XIN is a comprehensive ecosystem where every member not only connects but also grows sustainably within a secure, innovative digital network deeply rooted in local cultural identity.',NULL,'2025-05-29 21:09:05'),(50,'theme-xintel-ecosystem_sub_section_1_pin_icon','',NULL,'2025-05-29 21:09:05'),(51,'theme-xintel-ecosystem_sub_section_1_heading','Strong Community Connection',NULL,'2025-05-29 21:09:05'),(52,'theme-xintel-ecosystem_sub_section_1_content','From <b>XIN-Tel</b> – a global connectivity platform, to <b>XIN-Travel</b> – a space for preserving and promoting local culture, we build community hubs. With <b>XIN-Star</b>, users tell the stories of their regions through video, preserving experiences with technology.',NULL,'2025-05-29 21:09:05'),(53,'theme-xintel-ecosystem_sub_section_2_pin_icon','',NULL,'2025-05-29 21:09:05'),(54,'theme-xintel-ecosystem_sub_section_2_heading','Earning Profits',NULL,'2025-05-29 21:09:05'),(55,'theme-xintel-ecosystem_sub_section_2_content','<b>XIN-Shop</b> supports local businesses in launching online stores and engaging in peer-to-peer commerce. <b>XIN-Game</b> offers an entertainment space where players can interact, co-create, and earn income from their content.',NULL,'2025-05-29 21:09:05'),(56,'theme-xintel-ecosystem_sub_section_3_pin_icon','',NULL,'2025-05-29 21:09:05'),(57,'theme-xintel-ecosystem_sub_section_3_heading','Safe Payments',NULL,'2025-05-29 21:09:05'),(58,'theme-xintel-ecosystem_sub_section_3_content','<b>XIN-Fintech</b> ensures safe transactions, covering everything from payments to savings and credit. Powered by the <b>XIN token</b> system, users worldwide are connected through a transparent and trustworthy digital financial platform.',NULL,'2025-05-29 21:09:05'),(59,'theme-xintel-services_heading','Why Choose XIN?',NULL,'2025-05-29 21:09:05'),(60,'theme-xintel-services_sub_heading','XIN needs to exist because it addresses key challenges in the travel industry and bridges the gap between tourism businesses and blockchain technology. Here are a few reasons why XIN is essential:',NULL,'2025-05-29 21:09:05'),(61,'theme-xintel-service_1_content','<b>Cost Optimization &amp; Global Payments</b> <br> XIN leverages blockchain to reduce transaction fees and enable fast, transparent international payments.',NULL,'2025-05-29 21:09:05'),(62,'theme-xintel-service_1_icon','',NULL,'2025-05-29 21:09:05'),(63,'theme-xintel-service_2_content','<b>Community Connection &amp; Sharing</b><br> It creates opportunities for meaningful connections between travelers and locals, while sharing tourism generated value with the community.',NULL,'2025-05-29 21:09:05'),(64,'theme-xintel-service_2_icon','',NULL,'2025-05-29 21:09:05'),(65,'theme-xintel-service_3_content','<b>Transparency &amp; Trust</b> <br>Blockchain technology reveals the true value of services, fostering trust between users and providers.',NULL,'2025-05-29 21:09:05'),(66,'theme-xintel-service_3_icon','',NULL,'2025-05-29 21:09:05'),(67,'theme-xintel-service_4_content','<b>Innovative &amp; Engaging Technology</b> <br>NFTs and a reward system make travel more exciting, personalized, and memorable.',NULL,'2025-05-29 21:09:05'),(68,'theme-xintel-service_4_icon','',NULL,'2025-05-29 21:09:05'),(69,'theme-xintel-tokenomics_main_heading','Tokenomics &amp; Utility',NULL,'2025-05-29 21:09:05'),(70,'theme-xintel-tokenomics_sub_heading','250% Mining Distribution - No Private Sale:',NULL,'2025-05-29 21:09:05'),(71,'theme-xintel-tokenomics_description','The XIN Token is distributed entirely through a transparent mining mechanism — <b>with no pre-sale and no allocations for funds or the team</b>. This forms the foundation for building a fair, open, and sustainable ecosystem.',NULL,'2025-05-29 21:09:05'),(72,'theme-xintel-tokenomics_image','',NULL,'2025-05-29 21:09:05'),(73,'theme-xintel-tokenomics_mining_volume','121,995,104 / 12,000,000,000',NULL,'2025-05-29 21:09:05'),(74,'theme-xintel-tokenomics_utility_1_icon','',NULL,'2025-05-29 21:09:05'),(75,'theme-xintel-tokenomics_utility_1_title','Smart Contract',NULL,'2025-05-29 21:09:05'),(76,'theme-xintel-tokenomics_utility_1_link','#',NULL,'2025-05-29 21:09:05'),(77,'theme-xintel-tokenomics_utility_2_icon','',NULL,'2025-05-29 21:09:05'),(78,'theme-xintel-tokenomics_utility_2_title','Token Audit',NULL,'2025-05-29 21:09:05'),(79,'theme-xintel-tokenomics_utility_2_link','#',NULL,'2025-05-29 21:09:05'),(80,'theme-xintel-tokenomics_utility_3_icon','',NULL,'2025-05-29 21:09:05'),(81,'theme-xintel-tokenomics_utility_3_title','P2P Exchange',NULL,'2025-05-29 21:09:05'),(82,'theme-xintel-tokenomics_utility_3_link','#',NULL,'2025-05-29 21:09:05'),(83,'theme-xintel-tokenomics_utility_4_icon','',NULL,'2025-05-29 21:09:05'),(84,'theme-xintel-tokenomics_utility_4_title','CEX',NULL,'2025-05-29 21:09:05'),(85,'theme-xintel-tokenomics_utility_5_icon','',NULL,'2025-05-29 21:09:05'),(86,'theme-xintel-tokenomics_utility_5_title','DEX',NULL,'2025-05-29 21:09:05'),(87,'theme-xintel-team_heading','Core Team',NULL,'2025-05-29 21:09:05'),(88,'theme-xintel-team_1_image','',NULL,'2025-05-29 21:09:05'),(89,'theme-xintel-team_1_name','AlexTurner',NULL,'2025-05-29 21:09:05'),(90,'theme-xintel-team_1_position','CEO',NULL,'2025-05-29 21:09:05'),(91,'theme-xintel-team_1_number','01',NULL,'2025-05-29 21:09:05'),(92,'theme-xintel-team_1_bio','Innovation is at the heart of what I do. With XINTEL, I am committed to building a comprehensive social ecosystem that shapes the future of decentralized finance.',NULL,'2025-05-29 21:09:05'),(93,'theme-xintel-team_2_image','',NULL,'2025-05-29 21:09:05'),(94,'theme-xintel-team_2_name','Kent Baktas',NULL,'2025-05-29 21:09:05'),(95,'theme-xintel-team_2_position','CTO',NULL,'2025-05-29 21:09:05'),(96,'theme-xintel-team_2_number','02',NULL,'2025-05-29 21:09:05'),(97,'theme-xintel-team_2_bio','I believe that technology must always\nevolve. With XIN, we provide sustainable\nand innovative blockchain solutions.',NULL,'2025-05-29 21:09:05'),(98,'theme-xintel-team_3_image','',NULL,'2025-05-29 21:09:05'),(99,'theme-xintel-team_3_name','Dusan Zica',NULL,'2025-05-29 21:09:05'),(100,'theme-xintel-team_3_position','CMO',NULL,'2025-05-29 21:09:05'),(101,'theme-xintel-team_3_number','03',NULL,'2025-05-29 21:09:05'),(102,'theme-xintel-team_3_bio','I don\'t just tell stories, I build worlds. XIN is where the community comes together to shape the future of Web3.',NULL,'2025-05-29 21:09:05'),(103,'theme-xintel-partner_heading8','Working Alongside Trusted Partners',NULL,'2025-05-29 21:09:05'),(104,'theme-xintel-partner_sub_heading8','XIN is not just an idea – it is a project supported by leading names in Web3, marketing, and technology:',NULL,'2025-05-29 21:09:05'),(105,'theme-xintel-partner_1_image','',NULL,'2025-05-29 21:09:05'),(106,'theme-xintel-partner_1_name','[Partner Web3 Name]',NULL,'2025-05-29 21:09:05'),(107,'theme-xintel-partner_1_position','Blockchain integration &amp; smart contract security',NULL,'2025-05-29 21:09:05'),(108,'theme-xintel-partner_2_image','',NULL,'2025-05-29 21:09:05'),(109,'theme-xintel-partner_2_name','[Marketing Agency Name]',NULL,'2025-05-29 21:09:05'),(110,'theme-xintel-partner_2_position','Go to market strategy for Southeast Asia and the global market.',NULL,'2025-05-29 21:09:05'),(111,'theme-xintel-partner_3_image','',NULL,'2025-05-29 21:09:05'),(112,'theme-xintel-partner_3_name','[Tech Partner Name]',NULL,'2025-05-29 21:09:05'),(113,'theme-xintel-partner_3_position','Technical infrastructure &amp; cross platform expansion.',NULL,'2025-05-29 21:09:05'),(114,'theme-xintel-partner_quote','“XIN represents a unique approach, connecting content, travel, and a transparent tokenomics model. This is a model we believe will explode in Web3.” — <b>[VC/Investor Name]</b>, General Partner – <b>[Fund Name]</b>.',NULL,'2025-05-29 21:09:05'),(115,'theme-xintel-journey_heading','Roadmap',NULL,'2025-05-29 21:09:05'),(116,'theme-xintel-journey_1_title','Q4, 2024',NULL,'2025-05-29 21:09:05'),(117,'theme-xintel-journey_1_content','<ul><li>Launch eSIM and data packages for XIN: Expand country and region options.</li>\n                                        <li>Introduce travel guide feature and tour booking setup.</li>\n                                        <li>Activate check-in reward feature within the app.</li>\n                                        <li>Set up for 20-30 countries.</li>\n                                        <li>Connect with 250 brands and 5,000 local partners.</li>\n                                        <li>Connect Xintel with 6 countries: Thailand, Singapore, Malaysia, Indonesia, Philippines, and South Korea.</li>\n                                        <li>Organize XIN app and travel experience event in Thailand.</li>\n                                        <li>Goal: 250,000 users for Q4.</li>\n                                    </ul>',NULL,'2025-05-29 21:09:05'),(118,'theme-xintel-journey_2_title','Q1, 2025',NULL,'2025-05-29 21:09:05'),(119,'theme-xintel-journey_2_content','<ul><li>Integrate multi platform payment gateway and international payments.</li>\n                                        <li>Integrate booking for global trips, restaurants, hotels, and cafes.</li>\n                                        <li>Deploy KOLs for live streaming within the app.</li>\n                                        <li>Set up for 20-30 countries.</li>\n                                        <li>Connect with 200 brands and 10,000 local partners.</li>\n                                        <li>Connect Xintel with 6 countries.</li>\n                                        <li>Organize XIN app and travel experience event in Singapore.</li>\n                                        <li>Goal: 500,000 users for Q1.</li>\n                                    </ul>',NULL,'2025-05-29 21:09:05'),(120,'theme-xintel-journey_3_title','Q2, 2025',NULL,'2025-05-29 21:09:05'),(121,'theme-xintel-journey_3_content','<ul><li>Launch GameFi Hub: Support blockchain games and related activities.</li>\n                                        <li>Set up for 20-30 countries.</li>\n                                        <li>Connect with 300 brands and 15,000 local partners.</li>\n                                        <li>Connect Xintel with 6 countries.</li>\n                                        <li>Organize XIN app and travel experience event in Indonesia.</li>\n                                        <li>Goal: 1 million users for Q2.</li>\n                                    </ul>',NULL,'2025-05-29 21:09:05'),(122,'theme-xintel-journey_4_title','Q3, 2025',NULL,'2025-05-29 21:09:05'),(123,'theme-xintel-journey_4_content','<ul><li>Launch Only Fan feature.</li>\n                                        <li>List XIN token on DEX and CEX exchanges.</li>\n                                        <li>Set up for 20-30 countries.</li>\n                                        <li>Connect with 400 brands and 20,000 local partners.</li>\n                                        <li>Connect Xintel with 6 countries.</li>\n                                        <li>Organize XIN app and travel experience event in Indonesia.</li>\n                                        <li>Goal: 2 million users for Q3.</li>\n                                    </ul>',NULL,'2025-05-29 21:09:05'),(124,'theme-xintel-journey_5_title','Q4, 2025',NULL,'2025-05-29 21:09:05'),(125,'theme-xintel-journey_5_content','<ul><li>Launch Gateway Payment: Support international transactions and multi-platform services.</li>\n                                        <li>Release XIN chain and applications.</li>\n                                        <li>Set up for 20-30 countries.</li>\n                                        <li>Connect with 500 brands and 25,000 local partners.</li>\n                                        <li>Connect Xintel with 6 countries.</li>\n                                        <li>Organize XIN app and travel experience event in South Korea.</li>\n                                        <li>Goal: 3 million users for Q4.</li>\n                                    </ul>',NULL,'2025-05-29 21:09:05'),(126,'theme-xintel-investor_docs_title','Investor Documentation',NULL,'2025-05-29 21:09:05'),(127,'theme-xintel-investor_docs_description','We are committed to delivering a transparent, robust ecosystem that is ready for global expansion. All information for investors is thoroughly prepared, clear, and verifiable.',NULL,'2025-05-29 21:09:05'),(128,'theme-xintel-investor_docs_item_1_title','Pitch Deck',NULL,'2025-05-29 21:09:05'),(129,'theme-xintel-investor_docs_item_1_description','Project Overview, Operational Model, and Growth Potential.',NULL,'2025-05-29 21:09:05'),(130,'theme-xintel-investor_docs_item_1_button_text','Download PDF',NULL,'2025-05-29 21:09:05'),(131,'theme-xintel-investor_docs_item_1_link','#',NULL,'2025-05-29 21:09:05'),(132,'theme-xintel-investor_docs_item_2_title','Whitepaper',NULL,'2025-05-29 21:09:05'),(133,'theme-xintel-investor_docs_item_2_description','Product Architecture, Roadmap, and Detailed Development Logic.',NULL,'2025-05-29 21:09:05'),(134,'theme-xintel-investor_docs_item_2_button_text','Read now',NULL,'2025-05-29 21:09:05'),(135,'theme-xintel-investor_docs_item_2_link','#',NULL,'2025-05-29 21:09:05'),(136,'theme-xintel-investor_docs_item_3_title','Audit Report',NULL,'2025-05-29 21:09:05'),(137,'theme-xintel-investor_docs_item_3_description','Smart contract security audited by a third party.',NULL,'2025-05-29 21:09:05'),(138,'theme-xintel-investor_docs_item_3_button_text','Details',NULL,'2025-05-29 21:09:05'),(139,'theme-xintel-investor_docs_item_3_link','#',NULL,'2025-05-29 21:09:05'),(140,'theme-xintel-investor_docs_item_4_title','Tokenomics details',NULL,'2025-05-29 21:09:05'),(141,'theme-xintel-investor_docs_item_4_description','Distribution Mechanism, Utility, and Token Value Maintenance Strategy.',NULL,'2025-05-29 21:09:05'),(142,'theme-xintel-investor_docs_item_4_button_text','Explore more',NULL,'2025-05-29 21:09:05'),(143,'theme-xintel-investor_docs_item_4_link','#',NULL,'2025-05-29 21:09:05'),(144,'theme-xintel-investor_docs_item_5_title','Call with Founders / Investor Team.',NULL,'2025-05-29 21:09:05'),(145,'theme-xintel-investor_docs_item_5_description','',NULL,'2025-05-29 21:09:05'),(146,'theme-xintel-investor_docs_item_5_button_text','Book now',NULL,'2025-05-29 21:09:05'),(147,'theme-xintel-investor_docs_item_5_link','#',NULL,'2025-05-29 21:09:05'),(148,'theme-xintel-stats_heading','Real Data',NULL,'2025-05-29 21:09:05'),(149,'theme-xintel-stats_sub_heading','The project is not just an idea – XIN is growing stronger every day with a global community of users who engage, share, and earn rewards.',NULL,'2025-05-29 21:09:05'),(150,'theme-xintel-stats_counter_1_number','1245000',NULL,'2025-05-29 21:09:05'),(151,'theme-xintel-stats_counter_1_label','Registered Users',NULL,'2025-05-29 21:09:05'),(152,'theme-xintel-stats_counter_2_number','25',NULL,'2025-05-29 21:09:05'),(153,'theme-xintel-stats_counter_2_label','App Downloads',NULL,'2025-05-29 21:09:05'),(154,'theme-xintel-stats_counter_3_number','210000',NULL,'2025-05-29 21:09:05'),(155,'theme-xintel-stats_counter_3_label','Monthly Active Users (MAU)',NULL,'2025-05-29 21:09:05'),(156,'theme-xintel-stats_counter_4_number','92400000',NULL,'2025-05-29 21:09:05'),(157,'theme-xintel-stats_counter_4_label','XIN Token has been mined',NULL,'2025-05-29 21:09:05'),(158,'theme-xintel-stats_counter_5_number','30',NULL,'2025-05-29 21:09:05'),(159,'theme-xintel-stats_counter_5_label','Countries Currently Using',NULL,'2025-05-29 21:09:05'),(160,'theme-xintel-stats_counter_6_number','12000',NULL,'2025-05-29 21:09:05'),(161,'theme-xintel-stats_counter_6_label','Daily Travel Content Sharing Activities',NULL,'2025-05-29 21:09:05'),(162,'theme-xintel-partner_heading','STRATEGIC PARTNER',NULL,'2025-05-29 21:09:05'),(163,'theme-xintel-partner_sub_heading','We are building the XIN ecosystem alongside leading partners across various sectors – from technology and finance to tourism and media. Trust and long-term collaboration are the foundation of every step forward.',NULL,'2025-05-29 21:09:05'),(164,'theme-xintel-partners','[]',NULL,'2025-05-29 21:09:05'),(165,'theme-xintel-download_background_image','',NULL,'2025-05-29 21:09:05'),(166,'theme-xintel-download_title','DOWNLOAD NOW!',NULL,'2025-05-29 21:09:05'),(167,'theme-xintel-download_appstore_link','#',NULL,'2025-05-29 21:09:05'),(168,'theme-xintel-download_playstore_link','#',NULL,'2025-05-29 21:09:05'),(169,'theme-xintel-footer_text','Pi Gaming Company Limited, Business Registration: 0317417762 issued by Ho Chi Minh City\r\nDepartment of Planning & Investment on 08/08/2022.\r\nPublishing License: 31716-8TTTTT issued by Ministry of Information & Communications on 29/10/2024.\r\nAddress: 4-6-8 Calmetre, Nguyen Thai Binh Ward, District 1, Ho Chi Minh City.\r\nPhone: 0888.744.955 | Email: hr@pigaming.co\r\nContent Manager: Nguyen Duy Thinh | Email: ndthinh2035@gmail.com',NULL,'2025-05-29 21:09:05'),(170,'theme-xintel-footer_contact_heading','Contact Us',NULL,'2025-05-29 21:09:05'),(171,'theme-xintel-footer_contact_email','support@xintel.co',NULL,'2025-05-29 21:09:05'),(172,'theme-xintel-footer_telegram_link','#',NULL,'2025-05-29 21:09:05'),(173,'theme-xintel-footer_facebook_link','https://www.facebook.com/profile.php?id=61561928653091&amp;mibextid=LQQJ4d',NULL,'2025-05-29 21:09:05'),(174,'theme-xintel-footer_youtube_link','https://www.youtube.com/channel/UC3dwgM2BCAcKXuzSsdw-1dQ',NULL,'2025-05-29 21:09:05'),(175,'theme-xintel-footer_tiktok_link','https://www.tiktok.com/@educhainglobal?is_from_webapp=1&amp;sender_device=pc',NULL,'2025-05-29 21:09:05'),(176,'theme-xintel-footer_twitter_link','https://x.com/Educhain_Global',NULL,'2025-05-29 21:09:05'),(177,'theme-xintel-footer_chat3_link','#',NULL,'2025-05-29 21:09:05'),(178,'theme-xintel-favicon','',NULL,'2025-05-29 21:09:05'),(179,'theme-xintel-logo','logo.png',NULL,'2025-05-29 21:09:05'),(180,'theme-xintel-blog_page_id','0',NULL,'2025-05-29 21:09:05'),(181,'theme-xintel-number_of_posts_in_a_category','12',NULL,'2025-05-29 21:09:05'),(182,'theme-xintel-number_of_posts_in_a_tag','12',NULL,'2025-05-29 21:09:05'),(183,'theme-xintel-login_background',NULL,NULL,'2025-05-29 21:09:05'),(184,'theme-xintel-register_background',NULL,NULL,'2025-05-29 21:09:05'),(185,'theme-xintel-cookie_consent_enable','yes',NULL,'2025-05-29 21:09:05'),(186,'theme-xintel-cookie_consent_style','full-width',NULL,'2025-05-29 21:09:05'),(187,'theme-xintel-cookie_consent_message','Your experience on this site will be improved by allowing cookies.',NULL,'2025-05-29 21:09:05'),(188,'theme-xintel-cookie_consent_button_text','Allow cookies',NULL,'2025-05-29 21:09:05'),(189,'theme-xintel-cookie_consent_learn_more_url','',NULL,'2025-05-29 21:09:05'),(190,'theme-xintel-cookie_consent_learn_more_text','',NULL,'2025-05-29 21:09:05'),(191,'theme-xintel-cookie_consent_background_color','#000',NULL,'2025-05-29 21:09:05'),(192,'theme-xintel-cookie_consent_text_color','#fff',NULL,'2025-05-29 21:09:05'),(193,'theme-xintel-cookie_consent_max_width','1170',NULL,'2025-05-29 21:09:05'),(194,'social_login_enable','0',NULL,'2025-05-29 21:09:05'),(195,'social_login_facebook_enable','0',NULL,'2025-05-29 21:09:05'),(196,'social_login_facebook_app_id','',NULL,'2025-05-29 21:09:05'),(197,'social_login_facebook_app_secret','',NULL,'2025-05-29 21:09:05'),(198,'social_login_google_enable','0',NULL,'2025-05-29 21:09:05'),(199,'social_login_google_app_id','',NULL,'2025-05-29 21:09:05'),(200,'social_login_google_app_secret','',NULL,'2025-05-29 21:09:05'),(201,'social_login_github_enable','0',NULL,'2025-05-29 21:09:05'),(202,'social_login_github_app_id','',NULL,'2025-05-29 21:09:05'),(203,'social_login_github_app_secret','',NULL,'2025-05-29 21:09:05'),(204,'social_login_linkedin_enable','0',NULL,'2025-05-29 21:09:05'),(205,'social_login_linkedin_app_id','',NULL,'2025-05-29 21:09:05'),(206,'social_login_linkedin_app_secret','',NULL,'2025-05-29 21:09:05'),(207,'social_login_linkedin-openid_enable','0',NULL,'2025-05-29 21:09:05'),(208,'social_login_linkedin-openid_app_id','',NULL,'2025-05-29 21:09:05'),(209,'social_login_linkedin-openid_app_secret','',NULL,'2025-05-29 21:09:05'),(210,'theme-xintel-social_links','[[{\"key\":\"name\",\"value\":\"Facebook\"},{\"key\":\"icon\"},{\"key\":\"url\",\"value\":null},{\"key\":\"image\",\"value\":\"fb.png\"},{\"key\":\"color\",\"value\":\"transparent\"},{\"key\":\"background-color\",\"value\":\"transparent\"}],[{\"key\":\"name\",\"value\":\"Gmail\"},{\"key\":\"icon\"},{\"key\":\"url\",\"value\":null},{\"key\":\"image\",\"value\":\"mail.png\"},{\"key\":\"color\",\"value\":\"transparent\"},{\"key\":\"background-color\",\"value\":\"transparent\"}],[{\"key\":\"name\",\"value\":\"Tiktok\"},{\"key\":\"icon\"},{\"key\":\"url\",\"value\":null},{\"key\":\"image\",\"value\":\"tiktok.png\"},{\"key\":\"color\",\"value\":\"transparent\"},{\"key\":\"background-color\",\"value\":\"transparent\"}]]',NULL,'2025-05-29 21:09:05'),(211,'theme-xintel-footer_site_description','Pi Gaming Company Limited, Business Registration: 0317417762 issued by Ho Chi Minh City\nDepartment of Planning &amp; Investment on 08/08/2022.\nPublishing License: 31716-8TTTTT issued by Ministry of Information &amp; Communications on 29/10/2024.\nAddress: 4-6-8 Calmetre, Nguyen Thai Binh Ward, District 1, Ho Chi Minh City.\nPhone: 0888.744.955 | Email: hr@pigaming.co\nContent Manager: Nguyen Duy Thinh | Email: ndthinh2035@gmail.com',NULL,'2025-05-29 21:09:05');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `settings` with 211 row(s)
--

--
-- Table structure for table slugs
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slugs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_id` bigint(20) unsigned NOT NULL,
  `reference_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slugs_reference_id_index` (`reference_id`),
  KEY `slugs_key_index` (`key`),
  KEY `slugs_prefix_index` (`prefix`),
  KEY `slugs_reference_index` (`reference_id`,`reference_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slugs`
--

LOCK TABLES `slugs` WRITE;
/*!40000 ALTER TABLE `slugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `slugs` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `slugs` with 0 row(s)
--

--
-- Table structure for table slugs_translations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slugs_translations` (
  `lang_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slugs_id` bigint(20) unsigned NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prefix` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`lang_code`,`slugs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slugs_translations`
--

LOCK TABLES `slugs_translations` WRITE;
/*!40000 ALTER TABLE `slugs_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `slugs_translations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `slugs_translations` with 0 row(s)
--

--
-- Table structure for table tags
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_id` bigint(20) unsigned DEFAULT NULL,
  `author_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Botble\\ACL\\Models\\User',
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `tags` with 0 row(s)
--

--
-- Table structure for table tags_translations
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags_translations` (
  `lang_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tags_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`lang_code`,`tags_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags_translations`
--

LOCK TABLES `tags_translations` WRITE;
/*!40000 ALTER TABLE `tags_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags_translations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `tags_translations` with 0 row(s)
--

--
-- Table structure for table user_meta
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_meta_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_meta`
--

LOCK TABLES `user_meta` WRITE;
/*!40000 ALTER TABLE `user_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_meta` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `user_meta` with 0 row(s)
--

--
-- Table structure for table users
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `first_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_id` bigint(20) unsigned DEFAULT NULL,
  `super_user` tinyint(1) NOT NULL DEFAULT '0',
  `manage_supers` tinyint(1) NOT NULL DEFAULT '0',
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@gmail.com',NULL,'$2y$12$mONlDFAl1SlFVwRl/2izUu1ZTDpv3r4ZI/2IGmIwm3sRlqskL988W','H4L12TpTeli8VJPURH80Bo3uDmGgxZZzogVv4YUvY0YrC9uPZg25NFbf298t','2025-05-29 02:47:44','2025-05-29 02:47:44','Admin','Admin','admin',NULL,1,1,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `users` with 1 row(s)
--

--
-- Table structure for table widgets
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `widget_id` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sidebar_id` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `data` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumped table `widgets` with 0 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Fri, 30 May 2025 04:16:35 +0000
